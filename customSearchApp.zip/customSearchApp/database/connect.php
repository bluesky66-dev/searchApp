<?php 
 try{
        $db = new PDO("mysql:host=localhost;dbname=crud_in_angular","root","magento");
        $db -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }catch(PDOException $e){
            die("Failed to connect with MySQL: " . $e->getMessage());
   }
?>